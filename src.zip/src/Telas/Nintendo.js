import React, { useState } from 'react';

import {
  ScrollView,
  View,
  Text,
  Image,
  TextInput,
  FlatList,
} from 'react-native';

import { MaterialCommunityIcons } from '@expo/vector-icons';

import estilos from '../styles/estilos';

export default function Nintendo() {

  const [favorito, setFavorito] = useState('');

  const jogos = [
    { id: '1', nome: 'Zelda TOTK' },
    { id: '2', nome: 'Mario Odyssey' },
    { id: '3', nome: 'Pokémon Scarlet' },
    { id: '4', nome: 'Animal Crossing' },
  ];

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.header}>
          <MaterialCommunityIcons
            name="nintendo-switch"
            size={40}
            color="#E60012"
          />

          <Text style={estilos.titulo}>
            Nintendo Switch
          </Text>
        </View>

        <Image
          source={require('../imagens/nintendo.jpg')}
          style={estilos.imagem}
        />

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Seu jogo favorito
          </Text>

          <TextInput
            style={estilos.input}
            placeholder="Digite aqui..."
            value={favorito}
            onChangeText={setFavorito}
          />

          <Text style={estilos.resposta}>
            {favorito}
          </Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Exclusivos famosos
          </Text>

          <FlatList
            data={jogos}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <Text style={estilos.itemLista}>
                🎮 {item.nome}
              </Text>
            )}
          />
        </View>

      </View>
    </ScrollView>
  );
}