import React, { useState } from 'react';
import {
  ScrollView,
  View,
  Text,
  Image,
  Switch,
} from 'react-native';

import { MaterialCommunityIcons } from '@expo/vector-icons';
import estilos from '../styles/estilos';

export default function PlayStation() {

  const [possuiPS5, setPossuiPS5] = useState(false);

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.header}>
          <MaterialCommunityIcons
            name="sony-playstation"
            size={40}
            color="#0070D1"
          />

          <Text style={estilos.titulo}>
            PlayStation 5
          </Text>
        </View>

        <Image
          source={require('../imagens/ps5.jpg')}
          style={estilos.imagem}
        />

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Sobre o Console
          </Text>

          <Text style={estilos.texto}>
            Console da Sony lançado em 2020 com SSD ultrarrápido,
            Ray Tracing e suporte a jogos em 4K.
          </Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Você possui um PS5?
          </Text>

          <Switch
            value={possuiPS5}
            onValueChange={setPossuiPS5}
            trackColor={{
              false: '#555',
              true: '#0070D1',
            }}
          />

          <Text style={estilos.resposta}>
            {possuiPS5
              ? 'Você possui um PS5!'
              : 'Ainda não possui um PS5'}
          </Text>
        </View>

      </View>
    </ScrollView>
  );
}