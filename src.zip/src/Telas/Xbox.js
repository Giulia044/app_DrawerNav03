import React, { useState } from 'react';

import {
  ScrollView,
  View,
  Text,
  Image,
} from 'react-native';

import Slider from '@react-native-community/slider';

import { MaterialCommunityIcons } from '@expo/vector-icons';

import estilos from '../styles/estilos';

export default function Xbox() {

  const [nota, setNota] = useState(8);

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.header}>
          <MaterialCommunityIcons
            name="microsoft-xbox"
            size={40}
            color="#107C10"
          />

          <Text style={estilos.titulo}>
            Xbox Series X
          </Text>
        </View>

        <Image
          source={require('../imagens/xbox.jpg')}
          style={estilos.imagem}
        />

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Game Pass
          </Text>

          <Text style={estilos.texto}>
            O Game Pass oferece centenas de jogos
            por assinatura.
          </Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>
            Avalie o Game Pass
          </Text>

          <Text style={estilos.texto}>
            Nota: {nota}/10
          </Text>

          <Slider
            minimumValue={0}
            maximumValue={10}
            step={1}
            value={nota}
            onValueChange={setNota}
          />

        </View>

      </View>
    </ScrollView>
  );
}