import { StyleSheet } from 'react-native';

export default StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },

  conteudo: {
    padding: 18,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },

  titulo: {
    color: '#FFF',
    fontSize: 30,
    fontWeight: '700',
    marginLeft: 10,
  },

  imagem: {
    width: '100%',
    height: 220,
    resizeMode: 'contain',
    marginBottom: 20,
  },

  card: {
    backgroundColor: '#1E293B',
    padding: 18,
    borderRadius: 20,
    marginBottom: 15,
  },

  subtitulo: {
    color: '#60A5FA',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 10,
  },

  texto: {
    color: '#E2E8F0',
    fontSize: 16,
    lineHeight: 24,
  },

  lista: {
    color: '#E2E8F0',
    fontSize: 16,
    lineHeight: 30,
  },
resposta: {
  color: '#60A5FA',
  fontSize: 18,
  fontWeight: 'bold',
  marginTop: 10,
},

input: {
  backgroundColor: '#FFF',
  borderRadius: 15,
  padding: 15,
  marginTop: 10,
},

itemLista: {
  color: '#FFF',
  fontSize: 16,
  marginBottom: 10,
},
});