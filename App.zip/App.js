import 'react-native-gesture-handler';
import React from 'react';

import { NavigationContainer } from '@react-navigation/native';

import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { MaterialCommunityIcons } from '@expo/vector-icons';

import PlayStation from './src/Telas/PlayStation';
import Xbox from './src/Telas/Xbox';
import Nintendo from './src/Telas/Nintendo';

const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

function TabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: '#111827',
          borderTopWidth: 0,
        },

        tabBarActiveTintColor: '#60A5FA',
        tabBarInactiveTintColor: '#9CA3AF',

        headerStyle: {
          backgroundColor: '#111827',
        },

        headerTintColor: '#FFF',
      }}
    >
      <Tab.Screen
        name="PlayStation"
        component={PlayStation}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="sony-playstation"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Xbox"
        component={Xbox}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="microsoft-xbox"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Nintendo"
        component={Nintendo}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="nintendo-switch"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>

      <Drawer.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: '#111827',
          },

          headerTintColor: '#FFF',

          drawerStyle: {
            backgroundColor: '#0F172A',
          },

          drawerActiveTintColor: '#60A5FA',
          drawerInactiveTintColor: '#FFF',
        }}
      >

        <Drawer.Screen
          name="Home Tabs"
          component={TabNavigator}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons
                name="view-dashboard"
                size={size}
                color={color}
              />
            ),
          }}
        />

        <Drawer.Screen
          name="PlayStation"
          component={PlayStation}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons
                name="sony-playstation"
                size={size}
                color={color}
              />
            ),
          }}
        />

        <Drawer.Screen
          name="Xbox"
          component={Xbox}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons
                name="microsoft-xbox"
                size={size}
                color={color}
              />
            ),
          }}
        />

        <Drawer.Screen
          name="Nintendo"
          component={Nintendo}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons
                name="nintendo-switch"
                size={size}
                color={color}
              />
            ),
          }}
        />

      </Drawer.Navigator>

    </NavigationContainer>
  );
}